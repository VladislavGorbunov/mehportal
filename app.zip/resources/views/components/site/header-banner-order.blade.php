<div class="container position-relative">
    <div class="header-banner-order mt-0 mb-4 d-flex justify-content-center align-items-center flex-column">
        <div class="col-12 col-md-8">
            <h1 class="text-center fs-4 p-0 m-0">{{ $headerTitle }}</h1>
            
        </div>
        
        <div class="header-banner-order-layout"></div>
    </div>

</div>

