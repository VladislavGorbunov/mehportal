<div class="row">
<div class="col-12 col-md-6">
    <p class="mb-3">Заказчик: <i class="bi bi-dash-lg"></i></p>
    <p class="mb-3">ИНН: <i class="bi bi-dash-lg"></i></p>
    <p class="mb-3">Регион: <i class="bi bi-dash-lg"></i></p>
    <p class="mb-3">Адрес: <i class="bi bi-dash-lg"></i></p>
</div>

<div class="col-12 col-md-6">
    <p class="mb-3">Контактное лицо: <i class="bi bi-dash-lg"></i></p>
    <p class="mb-3">Телефон: <i class="bi bi-dash-lg"></i></p>
    <p class="mb-3">Добавочный: <i class="bi bi-dash-lg"></i></p>
    <p class="mb-3">Email: <i class="bi bi-dash-lg"></i></p>
</div>
</div>