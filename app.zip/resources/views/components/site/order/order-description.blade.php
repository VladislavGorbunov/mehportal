<p class="mb-2 fs-5"><b>Описание заказа:</b></p>
<p>{{ $order['description'] }}</p>
<hr>