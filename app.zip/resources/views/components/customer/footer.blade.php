
<footer class="d-flex justify-content-center align-items-center border-top mt-4" style="height: 80px;"> 
    <div class="container">
    <div class="d-flex align-items-center"> 
        <span class="text-light">МЕХПОРТАЛ © <?= date('Y') ?> г.</span> 
    </div> 
    
    
</footer>
</div>