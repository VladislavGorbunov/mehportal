@extends('layouts.login')

@section('title', 'МЕХПОРТАЛ - авторизация администратора')
@section('description', 'Вход в личный кабинет администратора')

@section('content')

<x-admin.login-admin />

@endsection