@extends('layouts.admin-panel')

@section('title', 'Панель администратора - МЕХПОРТАЛ')
@section('description', 'Панель администратора - МЕХПОРТАЛ')

@section('content')
    <h2 class="fs-4">Личный кабинет администратора</h2>
        <x-site.message />
    
@endsection