<?php if(session('message')): ?>
    <div class="alert alert-success mt-3 text-center">
        <small><?php echo e(session('message')); ?></small>
    </div>
<?php endif; ?><?php /**PATH D:\Programs\OSPanel\domains\mehportal\resources\views/components/site/message.blade.php ENDPATH**/ ?>