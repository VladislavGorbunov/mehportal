<?php $__env->startSection('title', 'Панель исполнителя - добавить компанию'); ?>
<?php $__env->startSection('description', 'Панель исполнителя - добавить компанию'); ?>

<?php $__env->startSection('content'); ?>

<h2 class="fs-4">Добавление предприятия</h2>

<?php if (isset($component)) { $__componentOriginalf9e631c51a63debd1f232a05c837896c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf9e631c51a63debd1f232a05c837896c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.executor.company-data-form','data' => ['legalForms' => $legal_forms,'regions' => $regions,'categoriesServices' => $categories_services]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('executor.company-data-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['legalForms' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($legal_forms),'regions' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($regions),'categoriesServices' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($categories_services)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf9e631c51a63debd1f232a05c837896c)): ?>
<?php $attributes = $__attributesOriginalf9e631c51a63debd1f232a05c837896c; ?>
<?php unset($__attributesOriginalf9e631c51a63debd1f232a05c837896c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf9e631c51a63debd1f232a05c837896c)): ?>
<?php $component = $__componentOriginalf9e631c51a63debd1f232a05c837896c; ?>
<?php unset($__componentOriginalf9e631c51a63debd1f232a05c837896c); ?>
<?php endif; ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.executor-panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programs\OSPanel\domains\mehportal\resources\views/executor/add-company.blade.php ENDPATH**/ ?>