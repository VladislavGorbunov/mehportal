<a class="navbar-brand" href="/">
    МЕХ<img src="/images/logo.png" class="logo-icon" alt="МЕХПОРТАЛ - заказы на металлообработку в открытом доступе">ПОРТАЛ
</a><?php /**PATH D:\Programs\OSPanel\domains\mehportal\resources\views/components/site/logo.blade.php ENDPATH**/ ?>