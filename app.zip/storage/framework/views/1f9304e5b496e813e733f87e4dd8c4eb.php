<?php if (isset($component)) { $__componentOriginal4a0e569ed79eb5f00ed3333d1c970f13 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4a0e569ed79eb5f00ed3333d1c970f13 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.errors','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('site.errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4a0e569ed79eb5f00ed3333d1c970f13)): ?>
<?php $attributes = $__attributesOriginal4a0e569ed79eb5f00ed3333d1c970f13; ?>
<?php unset($__attributesOriginal4a0e569ed79eb5f00ed3333d1c970f13); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4a0e569ed79eb5f00ed3333d1c970f13)): ?>
<?php $component = $__componentOriginal4a0e569ed79eb5f00ed3333d1c970f13; ?>
<?php unset($__componentOriginal4a0e569ed79eb5f00ed3333d1c970f13); ?>
<?php endif; ?>
<form method="post" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
    <div class="row mt-3">
        <div class="col-12 col-md-6">
            <div class="mb-3">
  				<label class="form-label">Название заказа:</label>
  				<input type="text" class="form-control" name="title" placeholder="" value="<?php echo e(old('title')); ?>">
			</div>

            <div class="mb-3">
  				<label class="form-label">Количество:</label>
  				<input type="number" class="form-control" name="quantity" placeholder="" value="<?php echo e(old('quantity')); ?>">
			</div>
        </div>

        <div class="col-12 col-md-6">
            <div class="mb-3">
  				<label class="form-label">Проходная цена руб.: <small>Значение 0 означает договорную цену</small></label>
  				<input type="number" class="form-control" name="price" placeholder="" value="<?php echo e(old('price')); ?>">
			</div>

            <div class="mb-3">
  				<label class="form-label">Дата сбора предложений до:</label>
  				<input type="date" class="form-control" name="closing_date" placeholder="" min="<?= date('Y-m-d') ?>" value="<?php echo e(old('closing_date')); ?>">
			</div>
        </div>

        <div class="mb-3">
            <label class="form-label">Описание заказа:</label>
            <textarea class="form-control" name="description" rows="6"><?php echo e(old('description')); ?></textarea>
        </div>

        
            <label class="form-label">Чертежи и дополнительные файлы:</label>
            <div class="col-12 col-md-6 mt-2">
                <input type="file" class="order-image-input" name="order_image_file" accept=".jpg,.png" hidden>
                <div class="file-column d-flex justify-content-center align-items-center flex-column order-image">
                    <i class="bi bi-file-image fs-1"></i>
                    <p class="m-0 mt-2 title">Основной чертёж</p>
                    <span class="m-0"><small>Файл в формате: JPG или PNG</small></span>
                    <small>Будет виден на странице поиска и в карточке заказа.</small>
                </div>
            </div>
            <div class="col-12 col-md-6 mt-2">
                <input type="file" class="order-file-input" name="order_archive_file" accept=".zip,.rar" hidden>
                <div class="file-column d-flex justify-content-center align-items-center flex-column order-file">
                    <i class="bi bi-file-zip fs-1"></i>
                    <p class="m-0 mt-2 title">Архив с доп. файлами</p>
                    <span class="m-0"><small>Файл в формате: RAR или ZIP</small></span>
                    <small>Архив будет доступен для скачивания в карточке заказа.</small>
                </div>
            </div>
        

        <div class="row mt-4 mb-3">
        <label class="form-label mb-3">В каких категориях размещаем заказ:</label>
      
        <?php $__currentLoopData = $categoriesServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            <div class="col-12 col-md-4 mb-4">
                    <label class="form-check-label mt-2">
                           <b><?php echo e($category->title); ?></b>
                    </label>
                    <div class="form-check">
                    <?php $__currentLoopData = $category->servicesAll; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                        <label class="form-check-label mt-2">
                            <input class="form-check-input" type="checkbox" id="services_checkbox" data-parent-id="<?php echo e($category->id); ?>" value="<?php echo e($service->id); ?>" name="categories[]">
                                <?php echo e($service->title); ?>

                        </label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <button type="submit" class="btn btn-blue mt-3 mb-3">Разместить заказ</button>
</form>

<script>
    const services_checkbox = document.querySelectorAll('#services_checkbox')
    let parent_id
    let parent_ckeckbox

    services_checkbox.forEach((checkbox) => {
        checkbox.addEventListener('change', (e) => {
            parent_id = e.target.getAttribute('data-parent-id')
            parent_ckeckbox = document.querySelector(`[data-parent="${parent_id}"]`);
            parent_ckeckbox.checked = true
        })
    })

    // Input главного чертежа
    const order_image = document.querySelector('.order-image')
    const order_image_input = document.querySelector('.order-image-input')

    const order_file = document.querySelector('.order-file')
    const order_file_input = document.querySelector('.order-file-input')

    order_image.addEventListener('click', () => {
        order_image_input.click()
    })

    order_file.addEventListener('click', () => {
        order_file_input.click()
    })
</script><?php /**PATH D:\Programs\OSPanel\domains\mehportal\resources\views/components/customer/add-order-form.blade.php ENDPATH**/ ?>