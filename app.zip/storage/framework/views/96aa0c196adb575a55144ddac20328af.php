<?php $__env->startSection('title', 'МЕХПОРТАЛ - авторизация исполнителя'); ?>
<?php $__env->startSection('description', 'Вход в личный кабинет исполнителя'); ?>

<?php $__env->startSection('content'); ?>

<?php if (isset($component)) { $__componentOriginaleca7352c17e429b4778266d3d3718b3d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaleca7352c17e429b4778266d3d3718b3d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.executor.login-executor','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('executor.login-executor'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaleca7352c17e429b4778266d3d3718b3d)): ?>
<?php $attributes = $__attributesOriginaleca7352c17e429b4778266d3d3718b3d; ?>
<?php unset($__attributesOriginaleca7352c17e429b4778266d3d3718b3d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaleca7352c17e429b4778266d3d3718b3d)): ?>
<?php $component = $__componentOriginaleca7352c17e429b4778266d3d3718b3d; ?>
<?php unset($__componentOriginaleca7352c17e429b4778266d3d3718b3d); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programs\OSPanel\domains\mehportal\resources\views/executor/login-executor.blade.php ENDPATH**/ ?>