<?php $__env->startSection('title', 'МЕХПОРТАЛ - авторизация заказчика'); ?>
<?php $__env->startSection('description', 'Вход в личный кабинет для заказчика'); ?>

<?php $__env->startSection('content'); ?>

<?php if (isset($component)) { $__componentOriginal8c1d2ca5518ba2ce2c3e90c006cd07cd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c1d2ca5518ba2ce2c3e90c006cd07cd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.customer.login-customer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('customer.login-customer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c1d2ca5518ba2ce2c3e90c006cd07cd)): ?>
<?php $attributes = $__attributesOriginal8c1d2ca5518ba2ce2c3e90c006cd07cd; ?>
<?php unset($__attributesOriginal8c1d2ca5518ba2ce2c3e90c006cd07cd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c1d2ca5518ba2ce2c3e90c006cd07cd)): ?>
<?php $component = $__componentOriginal8c1d2ca5518ba2ce2c3e90c006cd07cd; ?>
<?php unset($__componentOriginal8c1d2ca5518ba2ce2c3e90c006cd07cd); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programs\OSPanel\domains\mehportal\resources\views/customer/login-customer.blade.php ENDPATH**/ ?>