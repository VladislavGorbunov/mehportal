
    <div class="col-12 col-md-6">
        <p class="mb-2">Заказчик: <i class="bi bi-dash-lg"></i></p>
        <p class="mb-2">ИНН заказчика: <i class="bi bi-dash-lg"></i></p>
        <p class="mb-2">Регион заказчика: <i class="bi bi-dash-lg"></i></p>
        <p class="mb-2">Адрес заказчика: <i class="bi bi-dash-lg"></i></p>
    </div>

    <div class="col-12 col-md-6">
        <p class="mb-2">Контактное лицо: <i class="bi bi-dash-lg"></i></p>
        <p class="mb-2">Телефон заказчика: <i class="bi bi-dash-lg"></i></p>
        <p class="mb-2">Добавочный: <i class="bi bi-dash-lg"></i></p>
        <p class="mb-2">Email заказчика: <i class="bi bi-dash-lg"></i></p>
    </div>
<?php /**PATH D:\Programs\OSPanel\domains\mehportal\resources\views/components/site/hidden-customer-contacts.blade.php ENDPATH**/ ?>