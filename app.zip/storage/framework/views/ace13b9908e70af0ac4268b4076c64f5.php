<?php $__env->startSection('title', 'Панель заказчика - добавить компанию'); ?>
<?php $__env->startSection('description', 'Панель заказчика - добавить компанию'); ?>

<?php $__env->startSection('content'); ?>

<h2 class="fs-4">Добавление организации заказчика</h2>

<?php if (isset($component)) { $__componentOriginal383032db77098f036c836eb4b6dce289 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal383032db77098f036c836eb4b6dce289 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.customer.company-data-form','data' => ['legalForms' => $legal_forms,'regions' => $regions]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('customer.company-data-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['legalForms' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($legal_forms),'regions' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($regions)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal383032db77098f036c836eb4b6dce289)): ?>
<?php $attributes = $__attributesOriginal383032db77098f036c836eb4b6dce289; ?>
<?php unset($__attributesOriginal383032db77098f036c836eb4b6dce289); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal383032db77098f036c836eb4b6dce289)): ?>
<?php $component = $__componentOriginal383032db77098f036c836eb4b6dce289; ?>
<?php unset($__componentOriginal383032db77098f036c836eb4b6dce289); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.customer-panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programs\OSPanel\domains\mehportal\resources\views/customer/add-company.blade.php ENDPATH**/ ?>