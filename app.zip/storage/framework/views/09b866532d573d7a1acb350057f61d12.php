<?php if($errors->any()): ?>
    <div class="alert alert-danger mt-3">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><small><?php echo e($error); ?></small></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="alert alert-danger mt-3 text-center">
        <small><?php echo e(session('error')); ?></small>
    </div>
<?php endif; ?><?php /**PATH D:\Programs\OSPanel\domains\mehportal\resources\views/components/site/errors.blade.php ENDPATH**/ ?>