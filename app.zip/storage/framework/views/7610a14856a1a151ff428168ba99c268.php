<div class="d-flex flex-column flex-md-row">
    <p class="mb-3 me-2">Название заказа: <?php echo e($order['title']); ?></p>
        
    <?php if($order['active'] == true): ?>
        <div class="active-order-badge text-center me-2">Заказ открыт</div>
    <?php endif; ?>

    <?php if($order['archive'] == true): ?>
        <div class="archive-order-badge text-center me-2">Заказ закрыт</div>
    <?php endif; ?>
</div><?php /**PATH D:\Programs\OSPanel\domains\mehportal\resources\views/components/site/order/order-title-badge.blade.php ENDPATH**/ ?>