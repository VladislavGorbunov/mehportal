<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('description', $description); ?>

<?php $__env->startSection('content'); ?>

    <div class="mt-5">
        <div class="d-md-flex align-items-center">
        
            <div class="flex-grow-1">
                <h2 class="text-center text-md-start mt-0 mb-0">Открытые заказы на сегодня</h2> 
            </div>

            <div class="d-flex flex-row justify-content-end">
                <div class="row gx-3">
                    <div class="col-12 col-md-auto text-center mb-2 mb-md-0">
                        <div class="col-12 link-all-orders-block">
                            <a href="">Смотреть все заказы</a>
                        </div>
                    </div>

                    <div class="col-12 col-md-auto text-center mb-2 mb-md-0">
                        <div class="col-12 count-orders-block">
                            <b>Активных заказов: <?php echo e($count_orders); ?></b>
                        </div>
                    </div>

                    <div class="col-12 col-md-auto text-center mb-2 mb-md-0">
                        <div class="col-12 count-archive-orders-block">
                            <b>Заказов в архиве: <?php echo e($archive_count_orders); ?></b>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        
    </div>
    <?php if(!empty($orders)): ?>
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if (isset($component)) { $__componentOriginaldf340c465e2be5254fc4a83f77405942 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldf340c465e2be5254fc4a83f77405942 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.order-block','data' => ['order' => $order,'regionSlug' => $region_slug]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('site.order-block'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['order' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($order),'regionSlug' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($region_slug)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldf340c465e2be5254fc4a83f77405942)): ?>
<?php $attributes = $__attributesOriginaldf340c465e2be5254fc4a83f77405942; ?>
<?php unset($__attributesOriginaldf340c465e2be5254fc4a83f77405942); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldf340c465e2be5254fc4a83f77405942)): ?>
<?php $component = $__componentOriginaldf340c465e2be5254fc4a83f77405942; ?>
<?php unset($__componentOriginaldf340c465e2be5254fc4a83f77405942); ?>
<?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
        <?php if (isset($component)) { $__componentOriginal7fee2450e184de190030df74a475ccf0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7fee2450e184de190030df74a475ccf0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.add-order-banner','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('site.add-order-banner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7fee2450e184de190030df74a475ccf0)): ?>
<?php $attributes = $__attributesOriginal7fee2450e184de190030df74a475ccf0; ?>
<?php unset($__attributesOriginal7fee2450e184de190030df74a475ccf0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7fee2450e184de190030df74a475ccf0)): ?>
<?php $component = $__componentOriginal7fee2450e184de190030df74a475ccf0; ?>
<?php unset($__componentOriginal7fee2450e184de190030df74a475ccf0); ?>
<?php endif; ?>
    <?php else: ?>
        <?php if (isset($component)) { $__componentOriginald35176d52c5e42a1beee3699b7aa0c88 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald35176d52c5e42a1beee3699b7aa0c88 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.no-order','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('site.no-order'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald35176d52c5e42a1beee3699b7aa0c88)): ?>
<?php $attributes = $__attributesOriginald35176d52c5e42a1beee3699b7aa0c88; ?>
<?php unset($__attributesOriginald35176d52c5e42a1beee3699b7aa0c88); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald35176d52c5e42a1beee3699b7aa0c88)): ?>
<?php $component = $__componentOriginald35176d52c5e42a1beee3699b7aa0c88; ?>
<?php unset($__componentOriginald35176d52c5e42a1beee3699b7aa0c88); ?>
<?php endif; ?>
    <?php endif; ?>


    <?php echo e($paginate->links()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programs\OSPanel\domains\mehportal\resources\views/site/orders.blade.php ENDPATH**/ ?>