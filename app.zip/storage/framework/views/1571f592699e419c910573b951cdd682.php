<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('description', $description); ?>

<?php $__env->startSection('content'); ?>

    <?php if (isset($component)) { $__componentOriginal833caf935dd0fb2a02f7b40484cbdd97 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal833caf935dd0fb2a02f7b40484cbdd97 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.order.order','data' => ['order' => $order,'regionSlug' => $region_slug,'customerCheck' => $customerCheck]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('site.order.order'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['order' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($order),'regionSlug' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($region_slug),'customerCheck' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($customerCheck)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal833caf935dd0fb2a02f7b40484cbdd97)): ?>
<?php $attributes = $__attributesOriginal833caf935dd0fb2a02f7b40484cbdd97; ?>
<?php unset($__attributesOriginal833caf935dd0fb2a02f7b40484cbdd97); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal833caf935dd0fb2a02f7b40484cbdd97)): ?>
<?php $component = $__componentOriginal833caf935dd0fb2a02f7b40484cbdd97; ?>
<?php unset($__componentOriginal833caf935dd0fb2a02f7b40484cbdd97); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.order', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programs\OSPanel\domains\mehportal\resources\views/site/order.blade.php ENDPATH**/ ?>