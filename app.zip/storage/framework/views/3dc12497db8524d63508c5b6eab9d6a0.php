<?php $__env->startSection('title', 'МЕХПОРТАЛ - регистрация заказчика'); ?>
<?php $__env->startSection('description', 'Регистрация заказчика на портале - МЕХПОРТАЛ'); ?>

<?php $__env->startSection('content'); ?>

<?php if (isset($component)) { $__componentOriginal707d510513b1d0cb4cc47044af613b23 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal707d510513b1d0cb4cc47044af613b23 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.customer.registration-customer','data' => ['regions' => $regions]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('customer.registration-customer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['regions' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($regions)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal707d510513b1d0cb4cc47044af613b23)): ?>
<?php $attributes = $__attributesOriginal707d510513b1d0cb4cc47044af613b23; ?>
<?php unset($__attributesOriginal707d510513b1d0cb4cc47044af613b23); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal707d510513b1d0cb4cc47044af613b23)): ?>
<?php $component = $__componentOriginal707d510513b1d0cb4cc47044af613b23; ?>
<?php unset($__componentOriginal707d510513b1d0cb4cc47044af613b23); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.registration', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programs\OSPanel\domains\mehportal\resources\views/customer/registration-customer.blade.php ENDPATH**/ ?>