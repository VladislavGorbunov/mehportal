<?php if (isset($component)) { $__componentOriginalfae326133fcc0126c8026a06edd1d13c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfae326133fcc0126c8026a06edd1d13c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.top-menu','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('site.top-menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfae326133fcc0126c8026a06edd1d13c)): ?>
<?php $attributes = $__attributesOriginalfae326133fcc0126c8026a06edd1d13c; ?>
<?php unset($__attributesOriginalfae326133fcc0126c8026a06edd1d13c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfae326133fcc0126c8026a06edd1d13c)): ?>
<?php $component = $__componentOriginalfae326133fcc0126c8026a06edd1d13c; ?>
<?php unset($__componentOriginalfae326133fcc0126c8026a06edd1d13c); ?>
<?php endif; ?>

<nav class="navbar navbar-expand-lg navbar-light bg-light py-4">
  <div class="container">
    <?php if (isset($component)) { $__componentOriginalef0f557f73dbbb73359670ec0d50c899 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalef0f557f73dbbb73359670ec0d50c899 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.logo','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('site.logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalef0f557f73dbbb73359670ec0d50c899)): ?>
<?php $attributes = $__attributesOriginalef0f557f73dbbb73359670ec0d50c899; ?>
<?php unset($__attributesOriginalef0f557f73dbbb73359670ec0d50c899); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalef0f557f73dbbb73359670ec0d50c899)): ?>
<?php $component = $__componentOriginalef0f557f73dbbb73359670ec0d50c899; ?>
<?php unset($__componentOriginalef0f557f73dbbb73359670ec0d50c899); ?>
<?php endif; ?>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">

    <button type="button" class="btn btn-modal-city my-3 my-md-0 mx-md-2 d-block mx-auto" data-bs-toggle="modal" data-bs-target="#exampleModal">
        
    <i class="bi bi-cursor-fill"></i>
        <?php if($regionName): ?> 
          <?php echo e($regionName); ?>

        <?php else: ?>
          Выбрать город
        <?php endif; ?>
    </button>

      <ul class="navbar-nav me-auto mb-2 mb-lg-0 text-center">
        <li class="nav-item">
          <a href="#orders" class="nav-link link-blue" data-bs-toggle="modal" data-bs-target="#categories-services-modal">
            Заказы
          </a>
        </li>
        <li class="nav-item">
          <a href="#companies" class="nav-link link-blue" data-bs-toggle="modal" data-bs-target="#companies">Предприятия</a>
        </li>
        <li class="nav-item">
          <a class="nav-link link-blue" href="#companies">Поставщики</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="/contacts">Контакты</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="/tariffs">Тарифы</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="/blog">Блог</a>
        </li>
        
        
      </ul>
        <div class="d-flex justify-content-around align-items-center">
          <?php if(Auth::guard('customer')->check()): ?>
            <a href="<?php echo e(Route('login-customer')); ?>" class="btn btn-none-bg mx-2" target="_blank">Мой кабинет</a>
          <?php else: ?>
            <a href="<?php echo e(Route('login-customer')); ?>" class="btn btn-none-bg mx-2" target="_blank">Заказчикам</a>
          <?php endif; ?>
          
          <?php if(Auth::guard('executor')->check()): ?>
            <a href="<?php echo e(Route('login-executor')); ?>" class="btn btn-dark" target="_blank">Мой кабинет</a>
          <?php else: ?>
            <a href="<?php echo e(Route('login-executor')); ?>" class="btn btn-dark" target="_blank">Исполнителям</a>
          <?php endif; ?>
        </div>
    </div>
  </div>
</nav><?php /**PATH D:\Programs\OSPanel\domains\mehportal\resources\views/components/site/navbar.blade.php ENDPATH**/ ?>