<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('description', $description); ?>

<?php $__env->startSection('content'); ?>


<h2 class="text-center">Каталог предприятий</h2>
<?php if(! empty($companies)): ?>
    <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if (isset($component)) { $__componentOriginala4ec1abfa4f3c2fddd6277529ce08abb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala4ec1abfa4f3c2fddd6277529ce08abb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.companies.company-block','data' => ['company' => $company]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('site.companies.company-block'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['company' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($company)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala4ec1abfa4f3c2fddd6277529ce08abb)): ?>
<?php $attributes = $__attributesOriginala4ec1abfa4f3c2fddd6277529ce08abb; ?>
<?php unset($__attributesOriginala4ec1abfa4f3c2fddd6277529ce08abb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala4ec1abfa4f3c2fddd6277529ce08abb)): ?>
<?php $component = $__componentOriginala4ec1abfa4f3c2fddd6277529ce08abb; ?>
<?php unset($__componentOriginala4ec1abfa4f3c2fddd6277529ce08abb); ?>
<?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
    <?php if (isset($component)) { $__componentOriginal04f352245348839c5f6348a3f991b733 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal04f352245348839c5f6348a3f991b733 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.no-companies','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('site.no-companies'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal04f352245348839c5f6348a3f991b733)): ?>
<?php $attributes = $__attributesOriginal04f352245348839c5f6348a3f991b733; ?>
<?php unset($__attributesOriginal04f352245348839c5f6348a3f991b733); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal04f352245348839c5f6348a3f991b733)): ?>
<?php $component = $__componentOriginal04f352245348839c5f6348a3f991b733; ?>
<?php unset($__componentOriginal04f352245348839c5f6348a3f991b733); ?>
<?php endif; ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programs\OSPanel\domains\mehportal\resources\views/site/companies.blade.php ENDPATH**/ ?>