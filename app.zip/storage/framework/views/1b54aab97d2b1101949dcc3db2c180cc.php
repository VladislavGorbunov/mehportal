<div class="modal fade" id="companies" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-categories">
        <div class="modal-content">
            <div class="modal-header">
                <span class="fs-5"><b>Компании по металлообработке</b></span>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-12 col-md-4 mb-4">
                        <?php if($regionSlug !== ''): ?>
                            <a href="/<?php echo e($regionSlug); ?>/companies/category/<?php echo e($category->slug); ?>" class="category-link"><?php echo e($category->title); ?></a>
                        <?php else: ?>
                            <a href="<?php echo e($regionSlug); ?>/companies/category/<?php echo e($category->slug); ?>" class="category-link"><?php echo e($category->title); ?></a>
                        <?php endif; ?>
    
                        <?php $__currentLoopData = $category->servicesLimit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($regionSlug !== ''): ?>
                                <a href="/<?php echo e($regionSlug); ?>/companies/service/<?php echo e($service->slug); ?>" class="service-link"><?php echo e($service->title); ?></a>
                            <?php else: ?>
                                <a href="<?php echo e($regionSlug); ?>/companies/service/<?php echo e($service->slug); ?>" class="service-link"><?php echo e($service->title); ?></a>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="mt-2">
                            <a href="">Все категории</a>
                        </div>
                    </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

            </div>
        </div>
    </div>
</div><?php /**PATH D:\Programs\OSPanel\domains\mehportal\resources\views/components/companies.blade.php ENDPATH**/ ?>