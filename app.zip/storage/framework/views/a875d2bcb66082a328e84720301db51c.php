<!-- Modal city-->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header"><b>Выберите город</b>
       
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
          <div class="row"> 
            <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            <div class="col-6 text-center mb-3">
                <a href="/<?php echo e($city->slug); ?>"><?php echo e($city->name); ?></a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        
      </div>
    </div>
  </div>
</div><?php /**PATH D:\Programs\OSPanel\domains\mehportal\resources\views/components/modal-regions.blade.php ENDPATH**/ ?>