<!DOCTYPE html>
<html lang="ru">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title><?php echo $__env->yieldContent('title'); ?></title>
        <meta name="description" content="<?php echo $__env->yieldContent('description'); ?>">
        <link href="<?php echo e(asset('bootstrap/bootstrap-5.3.3-dist/css/bootstrap.min.css')); ?>" rel="stylesheet">
        <link rel="stylesheet" href="<?php echo e(asset('bootstrap/bootstrap-icons-1.13.1/bootstrap-icons.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/registration-page.css')); ?>">

        <link rel="apple-touch-icon" sizes="180x180" href="/images/apple-touch-icon.png">
        <link rel="icon" type="image/png" sizes="32x32" href="/images/favicon-32x32.png">
        <link rel="icon" type="image/png" sizes="16x16" href="/images/favicon-16x16.png">
        <link rel="manifest" href="/images/site.webmanifest">
       
    </head>

    <body>
        
        <div class="container">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
        
        <script src="<?php echo e(asset('js/imasked.js')); ?>"></script>
        <script src="<?php echo e(asset('bootstrap/bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js')); ?>"></script>
    </body>
</html>
<?php /**PATH D:\Programs\OSPanel\domains\mehportal\resources\views/layouts/registration.blade.php ENDPATH**/ ?>