<style>
    .sticky {
            position: sticky;
            top: 20px;
    }
</style>

<div class="mt-4 mb-5">
<div class="row">

    <?php if (isset($component)) { $__componentOriginal720218d441e3a5ae9e42bbdbc5226507 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal720218d441e3a5ae9e42bbdbc5226507 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.order.left-order-block','data' => ['order' => $order]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('site.order.left-order-block'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['order' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($order)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal720218d441e3a5ae9e42bbdbc5226507)): ?>
<?php $attributes = $__attributesOriginal720218d441e3a5ae9e42bbdbc5226507; ?>
<?php unset($__attributesOriginal720218d441e3a5ae9e42bbdbc5226507); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal720218d441e3a5ae9e42bbdbc5226507)): ?>
<?php $component = $__componentOriginal720218d441e3a5ae9e42bbdbc5226507; ?>
<?php unset($__componentOriginal720218d441e3a5ae9e42bbdbc5226507); ?>
<?php endif; ?>

    <div class="col-12 col-md-8">
        <div class="row">
            <?php if (isset($component)) { $__componentOriginal32d32dd6ae589776d4437e082607237d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal32d32dd6ae589776d4437e082607237d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.order.order-title-badge','data' => ['order' => $order]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('site.order.order-title-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['order' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($order)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal32d32dd6ae589776d4437e082607237d)): ?>
<?php $attributes = $__attributesOriginal32d32dd6ae589776d4437e082607237d; ?>
<?php unset($__attributesOriginal32d32dd6ae589776d4437e082607237d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal32d32dd6ae589776d4437e082607237d)): ?>
<?php $component = $__componentOriginal32d32dd6ae589776d4437e082607237d; ?>
<?php unset($__componentOriginal32d32dd6ae589776d4437e082607237d); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal4b3405598a9daacd308c21840efe9c3e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4b3405598a9daacd308c21840efe9c3e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.order.order-info','data' => ['order' => $order]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('site.order.order-info'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['order' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($order)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4b3405598a9daacd308c21840efe9c3e)): ?>
<?php $attributes = $__attributesOriginal4b3405598a9daacd308c21840efe9c3e; ?>
<?php unset($__attributesOriginal4b3405598a9daacd308c21840efe9c3e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4b3405598a9daacd308c21840efe9c3e)): ?>
<?php $component = $__componentOriginal4b3405598a9daacd308c21840efe9c3e; ?>
<?php unset($__componentOriginal4b3405598a9daacd308c21840efe9c3e); ?>
<?php endif; ?>
        </div>

        <?php if (isset($component)) { $__componentOriginal97faf140ad7bfcd006b2aa4ff18c872c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal97faf140ad7bfcd006b2aa4ff18c872c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.order.order-categories','data' => ['order' => $order,'regionSlug' => $regionSlug]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('site.order.order-categories'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['order' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($order),'regionSlug' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($regionSlug)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal97faf140ad7bfcd006b2aa4ff18c872c)): ?>
<?php $attributes = $__attributesOriginal97faf140ad7bfcd006b2aa4ff18c872c; ?>
<?php unset($__attributesOriginal97faf140ad7bfcd006b2aa4ff18c872c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal97faf140ad7bfcd006b2aa4ff18c872c)): ?>
<?php $component = $__componentOriginal97faf140ad7bfcd006b2aa4ff18c872c; ?>
<?php unset($__componentOriginal97faf140ad7bfcd006b2aa4ff18c872c); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginal09709cf28a7f2ef71286ae913bfe4af9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal09709cf28a7f2ef71286ae913bfe4af9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.order.order-description','data' => ['order' => $order]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('site.order.order-description'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['order' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($order)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal09709cf28a7f2ef71286ae913bfe4af9)): ?>
<?php $attributes = $__attributesOriginal09709cf28a7f2ef71286ae913bfe4af9; ?>
<?php unset($__attributesOriginal09709cf28a7f2ef71286ae913bfe4af9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal09709cf28a7f2ef71286ae913bfe4af9)): ?>
<?php $component = $__componentOriginal09709cf28a7f2ef71286ae913bfe4af9; ?>
<?php unset($__componentOriginal09709cf28a7f2ef71286ae913bfe4af9); ?>
<?php endif; ?>
        
        <p class="mt-3 mb-3 fs-5"><b>Контакты заказчика:</b></p>
           
            <?php if(Auth::guard('executor')->user()): ?>
                <?php if(Auth::guard('executor')->user()->premium || $order['customer_premium']): ?>
                    <?php if (isset($component)) { $__componentOriginala464e56f85198220c3de33b7ce4990be = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala464e56f85198220c3de33b7ce4990be = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.order.customer-contacts','data' => ['order' => $order]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('site.order.customer-contacts'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['order' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($order)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala464e56f85198220c3de33b7ce4990be)): ?>
<?php $attributes = $__attributesOriginala464e56f85198220c3de33b7ce4990be; ?>
<?php unset($__attributesOriginala464e56f85198220c3de33b7ce4990be); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala464e56f85198220c3de33b7ce4990be)): ?>
<?php $component = $__componentOriginala464e56f85198220c3de33b7ce4990be; ?>
<?php unset($__componentOriginala464e56f85198220c3de33b7ce4990be); ?>
<?php endif; ?>
                    <hr>
                    <?php if (isset($component)) { $__componentOriginal3d0ca6037ca949c0c56b7abb9eb1e535 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3d0ca6037ca949c0c56b7abb9eb1e535 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.order.customer-check','data' => ['check' => $customerCheck,'orderDate' => $order['date']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('site.order.customer-check'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['check' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($customerCheck),'orderDate' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($order['date'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3d0ca6037ca949c0c56b7abb9eb1e535)): ?>
<?php $attributes = $__attributesOriginal3d0ca6037ca949c0c56b7abb9eb1e535; ?>
<?php unset($__attributesOriginal3d0ca6037ca949c0c56b7abb9eb1e535); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3d0ca6037ca949c0c56b7abb9eb1e535)): ?>
<?php $component = $__componentOriginal3d0ca6037ca949c0c56b7abb9eb1e535; ?>
<?php unset($__componentOriginal3d0ca6037ca949c0c56b7abb9eb1e535); ?>
<?php endif; ?>
                <?php else: ?>
                    <?php if (isset($component)) { $__componentOriginal3dbcf21fe30f9d8659b7f2628aed11b9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3dbcf21fe30f9d8659b7f2628aed11b9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.order.hidden-customer-contacts','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('site.order.hidden-customer-contacts'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3dbcf21fe30f9d8659b7f2628aed11b9)): ?>
<?php $attributes = $__attributesOriginal3dbcf21fe30f9d8659b7f2628aed11b9; ?>
<?php unset($__attributesOriginal3dbcf21fe30f9d8659b7f2628aed11b9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3dbcf21fe30f9d8659b7f2628aed11b9)): ?>
<?php $component = $__componentOriginal3dbcf21fe30f9d8659b7f2628aed11b9; ?>
<?php unset($__componentOriginal3dbcf21fe30f9d8659b7f2628aed11b9); ?>
<?php endif; ?>
                    <hr>
                    <?php if (isset($component)) { $__componentOriginal4ac955e6cb28de5e4c74f1a0a3162c05 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4ac955e6cb28de5e4c74f1a0a3162c05 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.order.hidden-customer-check','data' => ['orderDate' => $order['date']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('site.order.hidden-customer-check'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['orderDate' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($order['date'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4ac955e6cb28de5e4c74f1a0a3162c05)): ?>
<?php $attributes = $__attributesOriginal4ac955e6cb28de5e4c74f1a0a3162c05; ?>
<?php unset($__attributesOriginal4ac955e6cb28de5e4c74f1a0a3162c05); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4ac955e6cb28de5e4c74f1a0a3162c05)): ?>
<?php $component = $__componentOriginal4ac955e6cb28de5e4c74f1a0a3162c05; ?>
<?php unset($__componentOriginal4ac955e6cb28de5e4c74f1a0a3162c05); ?>
<?php endif; ?>
                <?php endif; ?>
            <?php endif; ?>
       

        <?php if(Auth::guard('executor')->user()): ?>
            <?php if(!Auth::guard('executor')->user()->premium && !$order['customer_premium']): ?>
                <div class="alert alert-primary mt-4 text-center">
                    <small>Контакты заказчика доступны зарегистрированным исполнителям с премиум тарифом.</small><br>
                    <p class="mt-3 mb-1">Тариф <b>«Premium»</b> - от 3990 руб/месяц <a href="" class="buy-tarif ms-2">Подключить</a></p>
                </div>
           
            <?php endif; ?>
        <?php else: ?>
            <?php if (isset($component)) { $__componentOriginal3dbcf21fe30f9d8659b7f2628aed11b9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3dbcf21fe30f9d8659b7f2628aed11b9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.order.hidden-customer-contacts','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('site.order.hidden-customer-contacts'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3dbcf21fe30f9d8659b7f2628aed11b9)): ?>
<?php $attributes = $__attributesOriginal3dbcf21fe30f9d8659b7f2628aed11b9; ?>
<?php unset($__attributesOriginal3dbcf21fe30f9d8659b7f2628aed11b9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3dbcf21fe30f9d8659b7f2628aed11b9)): ?>
<?php $component = $__componentOriginal3dbcf21fe30f9d8659b7f2628aed11b9; ?>
<?php unset($__componentOriginal3dbcf21fe30f9d8659b7f2628aed11b9); ?>
<?php endif; ?>
            <hr>
            <?php if (isset($component)) { $__componentOriginal4ac955e6cb28de5e4c74f1a0a3162c05 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4ac955e6cb28de5e4c74f1a0a3162c05 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.order.hidden-customer-check','data' => ['orderDate' => $order['date']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('site.order.hidden-customer-check'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['orderDate' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($order['date'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4ac955e6cb28de5e4c74f1a0a3162c05)): ?>
<?php $attributes = $__attributesOriginal4ac955e6cb28de5e4c74f1a0a3162c05; ?>
<?php unset($__attributesOriginal4ac955e6cb28de5e4c74f1a0a3162c05); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4ac955e6cb28de5e4c74f1a0a3162c05)): ?>
<?php $component = $__componentOriginal4ac955e6cb28de5e4c74f1a0a3162c05; ?>
<?php unset($__componentOriginal4ac955e6cb28de5e4c74f1a0a3162c05); ?>
<?php endif; ?>
            <?php if(!$order['customer_premium']): ?>
            <div class="alert alert-primary mt-4 text-center">
                <small>Контакты заказчика доступны зарегистрированным исполнителям с премиум тарифом.</small><br>
                <p class="mt-3 mb-1">Тариф <b>«Premium»</b> - от 3500 руб/месяц <a href="<?php echo e(Route('login-executor')); ?>" class="buy-tarif ms-2" target="_blank">Подключиться</a></p>
            </div>
            <?php else: ?> 
                <div class="alert alert-primary mt-4 py-4 text-center">
                    <small>Контакты заказчика доступны всем зарегистрированным и авторизованным исполнителям с любым тарифом. <a href="<?php echo e(Route('login-executor')); ?>" class="buy-tarif ms-2" target="_blank">Войти</a></small>
                </div>
            <?php endif; ?>
        <?php endif; ?>

    </div>
</div>
</div><?php /**PATH D:\Programs\OSPanel\domains\mehportal\resources\views/components/site/order/order.blade.php ENDPATH**/ ?>