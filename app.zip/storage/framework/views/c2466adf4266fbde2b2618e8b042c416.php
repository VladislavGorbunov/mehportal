<p class="mb-2 fs-5"><b>Описание заказа:</b></p>
<p><?php echo e($order['description']); ?></p>
<hr><?php /**PATH D:\Programs\OSPanel\domains\mehportal\resources\views/components/site/order/order-description.blade.php ENDPATH**/ ?>