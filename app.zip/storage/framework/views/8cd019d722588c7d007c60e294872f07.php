<?php if (isset($component)) { $__componentOriginal4a0e569ed79eb5f00ed3333d1c970f13 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4a0e569ed79eb5f00ed3333d1c970f13 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.errors','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('site.errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4a0e569ed79eb5f00ed3333d1c970f13)): ?>
<?php $attributes = $__attributesOriginal4a0e569ed79eb5f00ed3333d1c970f13; ?>
<?php unset($__attributesOriginal4a0e569ed79eb5f00ed3333d1c970f13); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4a0e569ed79eb5f00ed3333d1c970f13)): ?>
<?php $component = $__componentOriginal4a0e569ed79eb5f00ed3333d1c970f13; ?>
<?php unset($__componentOriginal4a0e569ed79eb5f00ed3333d1c970f13); ?>
<?php endif; ?>
<div class="alert alert-warning text-center mt-3">Все поля обязательны для заполнения.</div>
    <form method="post">
    <?php echo csrf_field(); ?>
        <div class="row mt-3">
            <div class="col-12 col-md-6">
                <div class="mb-3">
                    <label class="form-label">Организационно-правовая форма:</label>
                        <select class="form-select" name="legal_form">
                            <?php $__currentLoopData = $legalForms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $legal_form): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(old('legal_form') == $legal_form->name): ?>
                                    <option value="<?php echo e($legal_form->name); ?>" selected><?php echo e($legal_form->name); ?> - <?php echo e($legal_form->full_name); ?></option>
                                <?php else: ?>
                                    <option value="<?php echo e($legal_form->name); ?>"><?php echo e($legal_form->name); ?> - <?php echo e($legal_form->full_name); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                </div>

				<div class="mb-3">
  					<label class="form-label">Название организации:</label>
  					<input type="text" class="form-control" name="title" value="<?php echo e(old('title')); ?>" placeholder="Например: «ТехноСистемы»">
				</div>

				<div class="mb-3">
  					<label class="form-label">ИНН организации:</label>
  					<input type="text" class="form-control" name="inn" value="<?php echo e(old('inn')); ?>" placeholder="Например: 178081376893">
				</div>

				<div class="mb-3">
                    <label class="form-label">Регион:</label>
                        <select class="form-select" name="region_id">
                            <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(old('region') == $region->id): ?>
                                    <option value="<?php echo e($region->id); ?>" selected><?php echo e($region->name); ?></option>
                                <?php else: ?>
                                    <option value="<?php echo e($region->id); ?>"><?php echo e($region->name); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                </div>

				<div class="mb-3">
  					<label class="form-label">Адрес:</label>
  					<input type="text" class="form-control" name="address" value="<?php echo e(old('address')); ?>" placeholder="Например: Санкт-Петербург, Боровая улица, д. 51 ">
				</div>
            </div>

            <div class="col-12 col-md-6">
				<div class="mb-3">
  					<label class="form-label">Контактное лицо (Ф.И.О):</label>
  					<input type="text" class="form-control" name="contact_person" value="<?php echo e(old('contact_person')); ?>" placeholder="Например: Иванов Евгений Владимирович">
				</div>

				<div class="mb-3">
  					<label class="form-label">Телефон контактного лица:</label>
  					<input type="tel" class="form-control" name="phone" value="<?php echo e(old('phone')); ?>" placeholder="Например: +7 (123) 456-78-90">
				</div>

				<div class="mb-3">
  					<label class="form-label">Добавочный номер при наличии:</label>
  					<input type="number" class="form-control" name="extension_number" value="<?php echo e(old('extension_number')); ?>" placeholder="Например: 363">
				</div>

				<div class="mb-3">
  					<label class="form-label">Email контактного лица:</label>
  					<input type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" placeholder="Например: petrov-dmk@mail.ru">
				</div>
            </div>
        </div>

        <div class="mb-3">
            <label class="form-label">Описание компании:</label>
            <textarea class="form-control" name="description" rows="6"><?php echo e(old('description')); ?></textarea>
        </div>

		<button type="submit" class="btn btn-blue mt-3 mb-3">Добавить организацию</button>
    </form><?php /**PATH D:\Programs\OSPanel\domains\mehportal\resources\views/components/customer/company-data-form.blade.php ENDPATH**/ ?>