<?php $__env->startSection('title', 'Панель заказчика - мои заказы'); ?>
<?php $__env->startSection('description', 'Панель заказчика - мои заказы'); ?>

<?php $__env->startSection('content'); ?>
<div class="px-2">
<h2 class="fs-4">Мои заказы</h2>
<div class="mt-4">
<?php if (isset($component)) { $__componentOriginal4a0e569ed79eb5f00ed3333d1c970f13 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4a0e569ed79eb5f00ed3333d1c970f13 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.errors','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('site.errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4a0e569ed79eb5f00ed3333d1c970f13)): ?>
<?php $attributes = $__attributesOriginal4a0e569ed79eb5f00ed3333d1c970f13; ?>
<?php unset($__attributesOriginal4a0e569ed79eb5f00ed3333d1c970f13); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4a0e569ed79eb5f00ed3333d1c970f13)): ?>
<?php $component = $__componentOriginal4a0e569ed79eb5f00ed3333d1c970f13; ?>
<?php unset($__componentOriginal4a0e569ed79eb5f00ed3333d1c970f13); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginal5d116857ec1345ea71941ee2547e932b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5d116857ec1345ea71941ee2547e932b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.message','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('site.message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5d116857ec1345ea71941ee2547e932b)): ?>
<?php $attributes = $__attributesOriginal5d116857ec1345ea71941ee2547e932b; ?>
<?php unset($__attributesOriginal5d116857ec1345ea71941ee2547e932b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5d116857ec1345ea71941ee2547e932b)): ?>
<?php $component = $__componentOriginal5d116857ec1345ea71941ee2547e932b; ?>
<?php unset($__componentOriginal5d116857ec1345ea71941ee2547e932b); ?>
<?php endif; ?>
<?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row mt-3 mb-4 p-3 border rounded">
        <div class="col-4">
            <img src="<?php echo e(Storage::disk('orders_images')->url($order['order_image'])); ?>" class="img-fluid order-image d-block mx-auto">
        </div>
        <?php
            $closing_date = date("d.m.Y", strtotime($order->closing_date));
        ?>
        <div class="col-8">
            <h4 class="order-title mb-3 me-2"><?php echo e($order->title); ?></h4>
            <?php if($order['active'] == true): ?>
                <div class="active-order-badge text-center me-2 mb-2">Заказ открыт</div>
            <?php endif; ?>

            <?php if($order['archive'] == true): ?>
                <div class="archive-order-badge text-center me-2 mb-2">Заказ закрыт</div>
            <?php endif; ?>

            <p class="mb-1">Номер заказа: <strong><?php echo e($order->id); ?></strong></p>
            <p class="mb-1">Необходимое количество:<strong> <?php echo e($order['quantity']); ?> шт.</strong></p>
            <p class="mb-1">Дата сбора КП: до <strong><?php echo e($closing_date); ?></strong> <small>- включительно</small></p>
            <hr>
            <p class="mb-1"><strong>Описание:</strong> <?php echo e($order->description); ?></p>
            
            
            <?php if($order['active'] == true): ?>
                <button class="btn btn-close-order mt-2" data-id="<?php echo e($order['id']); ?>">Закрыть заказ</button>
            <?php endif; ?>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>


<script>
    const btnClose = document.querySelectorAll('.btn-close-order')

    btnClose.forEach((btn) => {
        btn.addEventListener('click', (e) => {
            let id = e.target.getAttribute('data-id')
            let confirmation = confirm('Вы действительно хотите закрыть заказ?')

            if (confirmation) {
                window.location.href = `/customer/order/close/${id}`;
            }
        })
    })
</script>


<?php echo e($orders->links()); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.customer-panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programs\OSPanel\domains\mehportal\resources\views/customer/my-orders.blade.php ENDPATH**/ ?>