<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('description', $description); ?>

<?php $__env->startSection('content'); ?>
    <style>
        .tariff-title {
            font-weight: 500;
        }

        .low-price {
            background: rgb(48, 183, 84);
            font-weight: 400;
            padding: 6px 22px;
            border-radius: 5px;
            color: #fff;
        }
    </style>
    <div class="alert alert-primary px-3 py-4">
        <h2 class="fs-5 text-center mb-1">Бесплатный «Premium» статус для всех новых пользователей!</h2>
        <p class="text-center">Срок проведения акции до 31.12.2025 года.</p>
        <p class="text-center">Для того чтобы получить Premium-статус вам нужно всего лишь зарегистрироваться у нас на сайте.
            <br>Статус будет активирован автоматически и будет действовать до 31 декабря 2025 года включительно.
            После окончания действия бесплатного периода, Вы всегда сможете активировать его платно в личном кабинете, по тарифам указанным ниже.
        </p>
    </div>
    <?php if (isset($component)) { $__componentOriginal5afa8339fa53334492a9a945b9dd1908 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5afa8339fa53334492a9a945b9dd1908 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.tariffs-executor','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('site.tariffs-executor'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5afa8339fa53334492a9a945b9dd1908)): ?>
<?php $attributes = $__attributesOriginal5afa8339fa53334492a9a945b9dd1908; ?>
<?php unset($__attributesOriginal5afa8339fa53334492a9a945b9dd1908); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5afa8339fa53334492a9a945b9dd1908)): ?>
<?php $component = $__componentOriginal5afa8339fa53334492a9a945b9dd1908; ?>
<?php unset($__componentOriginal5afa8339fa53334492a9a945b9dd1908); ?>
<?php endif; ?>
    <hr>
    <?php if (isset($component)) { $__componentOriginal29b41249e3e7a5a7ca2d98f89074a384 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal29b41249e3e7a5a7ca2d98f89074a384 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.tariffs-customer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('site.tariffs-customer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal29b41249e3e7a5a7ca2d98f89074a384)): ?>
<?php $attributes = $__attributesOriginal29b41249e3e7a5a7ca2d98f89074a384; ?>
<?php unset($__attributesOriginal29b41249e3e7a5a7ca2d98f89074a384); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal29b41249e3e7a5a7ca2d98f89074a384)): ?>
<?php $component = $__componentOriginal29b41249e3e7a5a7ca2d98f89074a384; ?>
<?php unset($__componentOriginal29b41249e3e7a5a7ca2d98f89074a384); ?>
<?php endif; ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.order', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programs\OSPanel\domains\mehportal\resources\views/site/tariffs.blade.php ENDPATH**/ ?>