<nav class="navbar navbar-customer navbar-expand-lg navbar-light bg-light py-4">
  <div class="container">
    <?php if (isset($component)) { $__componentOriginalef0f557f73dbbb73359670ec0d50c899 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalef0f557f73dbbb73359670ec0d50c899 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.logo','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('site.logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalef0f557f73dbbb73359670ec0d50c899)): ?>
<?php $attributes = $__attributesOriginalef0f557f73dbbb73359670ec0d50c899; ?>
<?php unset($__attributesOriginalef0f557f73dbbb73359670ec0d50c899); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalef0f557f73dbbb73359670ec0d50c899)): ?>
<?php $component = $__componentOriginalef0f557f73dbbb73359670ec0d50c899; ?>
<?php unset($__componentOriginalef0f557f73dbbb73359670ec0d50c899); ?>
<?php endif; ?>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

  
    <div class="collapse navbar-collapse" id="navbarSupportedContent">

      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(Route('customer-index')); ?>">Главная страница</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/" target="_blank">Перейти на портал</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Помощь</a>
        </li>
        
      </ul>
        <div class="d-flex justify-content-around align-items-center">
            <a href="<?php echo e(Route('customer-logout')); ?>" class="btn btn-dark">Выйти</a>
        </div>
    </div>
  </div>
</nav><?php /**PATH D:\Programs\OSPanel\domains\mehportal\resources\views/components/customer/navbar.blade.php ENDPATH**/ ?>