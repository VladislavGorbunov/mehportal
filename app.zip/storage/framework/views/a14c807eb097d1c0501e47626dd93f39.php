<!DOCTYPE html>
<html lang="ru">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title><?php echo $__env->yieldContent('title'); ?></title>
        <meta name="description" content="<?php echo $__env->yieldContent('description'); ?>">
        <link href="<?php echo e(asset('bootstrap/bootstrap-5.3.3-dist/css/bootstrap.min.css')); ?>" rel="stylesheet">
        <link rel="stylesheet" href="<?php echo e(asset('bootstrap/bootstrap-icons-1.13.1/bootstrap-icons.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/customer-style.css')); ?>">

        <link rel="apple-touch-icon" sizes="180x180" href="/images/apple-touch-icon.png">
        <link rel="icon" type="image/png" sizes="32x32" href="/images/favicon-32x32.png">
        <link rel="icon" type="image/png" sizes="16x16" href="/images/favicon-16x16.png">
        <link rel="manifest" href="/images/site.webmanifest">
    </head>

    <body>

    <?php if (isset($component)) { $__componentOriginal2de1f84fdbb5aaf18d27cf49cd21a029 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2de1f84fdbb5aaf18d27cf49cd21a029 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.executor.navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('executor.navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2de1f84fdbb5aaf18d27cf49cd21a029)): ?>
<?php $attributes = $__attributesOriginal2de1f84fdbb5aaf18d27cf49cd21a029; ?>
<?php unset($__attributesOriginal2de1f84fdbb5aaf18d27cf49cd21a029); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2de1f84fdbb5aaf18d27cf49cd21a029)): ?>
<?php $component = $__componentOriginal2de1f84fdbb5aaf18d27cf49cd21a029; ?>
<?php unset($__componentOriginal2de1f84fdbb5aaf18d27cf49cd21a029); ?>
<?php endif; ?>
    <div class="container mt-4 mb-4">
        <div class="row">
            <?php if (isset($component)) { $__componentOriginald139045c70a9692a30b822de7ba408e6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald139045c70a9692a30b822de7ba408e6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.executor.sidebar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('executor.sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald139045c70a9692a30b822de7ba408e6)): ?>
<?php $attributes = $__attributesOriginald139045c70a9692a30b822de7ba408e6; ?>
<?php unset($__attributesOriginald139045c70a9692a30b822de7ba408e6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald139045c70a9692a30b822de7ba408e6)): ?>
<?php $component = $__componentOriginald139045c70a9692a30b822de7ba408e6; ?>
<?php unset($__componentOriginald139045c70a9692a30b822de7ba408e6); ?>
<?php endif; ?>
            <div class="col-12 col-md-9">
                <div class="col-12 px-2">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </div>
        </div>
    </div>   
 
    
        <script src="<?php echo e(asset('js/imasked.js')); ?>"></script>
        <script src="<?php echo e(asset('bootstrap/bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js')); ?>"></script>
    </body>
</html>
<?php /**PATH D:\Programs\OSPanel\domains\mehportal\resources\views/layouts/executor-panel.blade.php ENDPATH**/ ?>