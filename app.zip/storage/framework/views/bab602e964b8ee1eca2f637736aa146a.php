<!DOCTYPE html>
<html lang="ru">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title><?php echo $__env->yieldContent('title'); ?></title>
        <meta name="description" content="<?php echo $__env->yieldContent('description'); ?>">
        <link href="<?php echo e(asset('bootstrap/bootstrap-5.3.3-dist/css/bootstrap.min.css')); ?>" rel="stylesheet">
        <link rel="stylesheet" href="<?php echo e(asset('bootstrap/bootstrap-icons-1.13.1/bootstrap-icons.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
        <link rel="apple-touch-icon" sizes="180x180" href="/images/apple-touch-icon.png">
        <link rel="icon" type="image/png" sizes="32x32" href="/images/favicon-32x32.png">
        <link rel="icon" type="image/png" sizes="16x16" href="/images/favicon-16x16.png">
        <link rel="manifest" href="/images/site.webmanifest">
        <meta name="application-name" content="МЕХПОРТАЛ - открытые заказы на металлообработку по всей России.">
    </head>

    <body>
        <?php if (isset($component)) { $__componentOriginalc15cfcb543496a0c121db9179bca79b2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc15cfcb543496a0c121db9179bca79b2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.navbar','data' => ['regionName' => $region_name]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('site.navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['regionName' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($region_name)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc15cfcb543496a0c121db9179bca79b2)): ?>
<?php $attributes = $__attributesOriginalc15cfcb543496a0c121db9179bca79b2; ?>
<?php unset($__attributesOriginalc15cfcb543496a0c121db9179bca79b2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc15cfcb543496a0c121db9179bca79b2)): ?>
<?php $component = $__componentOriginalc15cfcb543496a0c121db9179bca79b2; ?>
<?php unset($__componentOriginalc15cfcb543496a0c121db9179bca79b2); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal3cf180bcc015c2495cb2f5f5e2a8abb2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3cf180bcc015c2495cb2f5f5e2a8abb2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.header-banner','data' => ['headerTitle' => $header_title]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('site.header-banner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['headerTitle' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($header_title)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3cf180bcc015c2495cb2f5f5e2a8abb2)): ?>
<?php $attributes = $__attributesOriginal3cf180bcc015c2495cb2f5f5e2a8abb2; ?>
<?php unset($__attributesOriginal3cf180bcc015c2495cb2f5f5e2a8abb2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3cf180bcc015c2495cb2f5f5e2a8abb2)): ?>
<?php $component = $__componentOriginal3cf180bcc015c2495cb2f5f5e2a8abb2; ?>
<?php unset($__componentOriginal3cf180bcc015c2495cb2f5f5e2a8abb2); ?>
<?php endif; ?>
        <div class="container">
            <?php echo $__env->yieldContent('content'); ?>
            
        </div>
        <?php if (isset($component)) { $__componentOriginal21120ef38d90a9d572330a5268a23b04 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21120ef38d90a9d572330a5268a23b04 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.footer','data' => ['regionSlug' => $region_slug]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('site.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['regionSlug' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($region_slug)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21120ef38d90a9d572330a5268a23b04)): ?>
<?php $attributes = $__attributesOriginal21120ef38d90a9d572330a5268a23b04; ?>
<?php unset($__attributesOriginal21120ef38d90a9d572330a5268a23b04); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21120ef38d90a9d572330a5268a23b04)): ?>
<?php $component = $__componentOriginal21120ef38d90a9d572330a5268a23b04; ?>
<?php unset($__componentOriginal21120ef38d90a9d572330a5268a23b04); ?>
<?php endif; ?>

        <script src="<?php echo e(asset('bootstrap/bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js')); ?>"></script>
    </body>
</html>
<?php /**PATH D:\Programs\OSPanel\domains\mehportal\resources\views/layouts/app.blade.php ENDPATH**/ ?>