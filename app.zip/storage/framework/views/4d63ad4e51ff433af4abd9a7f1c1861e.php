<?php $__env->startSection('title', 'Панель заказчика - профиль'); ?>
<?php $__env->startSection('description', 'Панель заказчика - профиль'); ?>

<?php $__env->startSection('content'); ?>

    <h2 class="fs-4">Мой профиль</h2>
        
    <?php if (isset($component)) { $__componentOriginal1b240a6bb7e935f09b124aadeb9c9d12 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1b240a6bb7e935f09b124aadeb9c9d12 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.customer.profile-edit','data' => ['customer' => $customer]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('customer.profile-edit'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['customer' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($customer)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1b240a6bb7e935f09b124aadeb9c9d12)): ?>
<?php $attributes = $__attributesOriginal1b240a6bb7e935f09b124aadeb9c9d12; ?>
<?php unset($__attributesOriginal1b240a6bb7e935f09b124aadeb9c9d12); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1b240a6bb7e935f09b124aadeb9c9d12)): ?>
<?php $component = $__componentOriginal1b240a6bb7e935f09b124aadeb9c9d12; ?>
<?php unset($__componentOriginal1b240a6bb7e935f09b124aadeb9c9d12); ?>
<?php endif; ?>
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.customer-panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programs\OSPanel\domains\mehportal\resources\views/customer/profile.blade.php ENDPATH**/ ?>