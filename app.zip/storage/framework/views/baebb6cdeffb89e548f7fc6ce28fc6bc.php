<footer class="pt-4 pb-4 pt-md-5 border-top">
    <div class="container">
    	<div class="row">
      		<div class="col-6 col-md-3 text-center">
        		<?php if (isset($component)) { $__componentOriginalef0f557f73dbbb73359670ec0d50c899 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalef0f557f73dbbb73359670ec0d50c899 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.logo','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('site.logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalef0f557f73dbbb73359670ec0d50c899)): ?>
<?php $attributes = $__attributesOriginalef0f557f73dbbb73359670ec0d50c899; ?>
<?php unset($__attributesOriginalef0f557f73dbbb73359670ec0d50c899); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalef0f557f73dbbb73359670ec0d50c899)): ?>
<?php $component = $__componentOriginalef0f557f73dbbb73359670ec0d50c899; ?>
<?php unset($__componentOriginalef0f557f73dbbb73359670ec0d50c899); ?>
<?php endif; ?>
        	
			<p class="text-light mt-2"><small>Наш сервис создан для быстрого и удобного поиска заказчиков и исполнителей
            на различные услуги по металлообработке во всех регионах России.</small>
        	</p>
      		</div>

      		<div class="col-6 col-md-3 text-center">
        		<h5>Заказчикам</h5>
        		<ul class="list-unstyled text-small">
          			<li class="mb-1"><a class="link-secondary text-decoration-none" href="#">Личный кабинет</a></li>
          			<li class="mb-1"><a class="link-secondary text-decoration-none" href="#">Разместить заказ</a></li>
          			<li class="mb-1"><a class="link-secondary text-decoration-none" href="#">Тарифные планы</a></li>
          			<li class="mb-1"><a class="link-secondary text-decoration-none" href="#">Вопросы-ответы</a></li>
        		</ul>
      		</div>
      		
			<div class="col-6 col-md-3 text-center">
        		<h5>Исполнителям</h5>
        		<ul class="list-unstyled text-small">
          			<li class="mb-1"><a class="link-secondary text-decoration-none" href="#">Личный кабинет</a></li>
          			<li class="mb-1"><a class="link-secondary text-decoration-none" href="#">Найти заказ</a></li>
          			<li class="mb-1"><a class="link-secondary text-decoration-none" href="#">Тарифные планы</a></li>
          			<li class="mb-1"><a class="link-secondary text-decoration-none" href="#">Реклама на сайте</a></li>
        		</ul>
      		</div>

      		<div class="col-6 col-md-3 text-center">
        		<h5>Информация</h5>
        		<ul class="list-unstyled text-small">
          			<li class="mb-1"><a class="link-secondary text-decoration-none" href="#">Наши контакты</a></li>
          			<li class="mb-1"><a class="link-secondary text-decoration-none" href="#">Реквизиты</a></li>
          			<li class="mb-1"><a class="link-secondary text-decoration-none" href="#">Оплата</a></li>
          			<li class="mb-1"><a class="link-secondary text-decoration-none" href="#">Договор-оферта</a></li>
          			<li class="mb-1"><a class="link-secondary text-decoration-none" href="#">Политика конфиденциальности</a></li>
        		</ul>
      		</div>

      		<div class="col-12 text-center text-light mt-5">
				МЕХПОРТАЛ © <?php echo date('Y') ?> г. - сервис поиска заказов на металлообработку и не только.
			</div>
    	</div>
	</div>

    <div class="col-10 col-md-3 cookie-modal d-flex align-items-center justify-content-around">
      <div><img src="/images/cookie-icon.svg" class="cookie-icon"></div>
      <div>Мы используем файлы cookie, они помогают нам делать этот сайт удобнее для пользователя.</div>
      <div class="mx-2"><button class="btn btn-cookie-ok">Хорошо</button></div>
    </div>

    <?php if (isset($component)) { $__componentOriginal4a747ca901cfe080c31ee1595e713fa8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4a747ca901cfe080c31ee1595e713fa8 = $attributes; } ?>
<?php $component = App\View\Components\ModalRegions::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal-regions'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ModalRegions::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4a747ca901cfe080c31ee1595e713fa8)): ?>
<?php $attributes = $__attributesOriginal4a747ca901cfe080c31ee1595e713fa8; ?>
<?php unset($__attributesOriginal4a747ca901cfe080c31ee1595e713fa8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4a747ca901cfe080c31ee1595e713fa8)): ?>
<?php $component = $__componentOriginal4a747ca901cfe080c31ee1595e713fa8; ?>
<?php unset($__componentOriginal4a747ca901cfe080c31ee1595e713fa8); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalf2f98d86e09a050f136366e48759dcbd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf2f98d86e09a050f136366e48759dcbd = $attributes; } ?>
<?php $component = App\View\Components\ServicesOrders::resolve(['regionSlug' => $regionSlug] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('services-orders'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ServicesOrders::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf2f98d86e09a050f136366e48759dcbd)): ?>
<?php $attributes = $__attributesOriginalf2f98d86e09a050f136366e48759dcbd; ?>
<?php unset($__attributesOriginalf2f98d86e09a050f136366e48759dcbd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf2f98d86e09a050f136366e48759dcbd)): ?>
<?php $component = $__componentOriginalf2f98d86e09a050f136366e48759dcbd; ?>
<?php unset($__componentOriginalf2f98d86e09a050f136366e48759dcbd); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal4c7cb5cf7aaaede1e01d749e09ca78b6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4c7cb5cf7aaaede1e01d749e09ca78b6 = $attributes; } ?>
<?php $component = App\View\Components\Companies::resolve(['regionSlug' => $regionSlug] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('companies'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Companies::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4c7cb5cf7aaaede1e01d749e09ca78b6)): ?>
<?php $attributes = $__attributesOriginal4c7cb5cf7aaaede1e01d749e09ca78b6; ?>
<?php unset($__attributesOriginal4c7cb5cf7aaaede1e01d749e09ca78b6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4c7cb5cf7aaaede1e01d749e09ca78b6)): ?>
<?php $component = $__componentOriginal4c7cb5cf7aaaede1e01d749e09ca78b6; ?>
<?php unset($__componentOriginal4c7cb5cf7aaaede1e01d749e09ca78b6); ?>
<?php endif; ?>
  </footer><?php /**PATH D:\Programs\OSPanel\domains\mehportal\resources\views/components/site/footer.blade.php ENDPATH**/ ?>