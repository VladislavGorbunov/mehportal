<?php $__env->startSection('title', 'Панель заказчика - добавить заказ'); ?>
<?php $__env->startSection('description', 'Панель заказчика - добавить заказ'); ?>

<?php $__env->startSection('content'); ?>

<h2 class="fs-4">Добавление заказа</h2>

<?php if (isset($component)) { $__componentOriginalafa3b059a847971eaf86fb3f85b67dc6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalafa3b059a847971eaf86fb3f85b67dc6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.customer.add-order-form','data' => ['categoriesServices' => $categories_services]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('customer.add-order-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['categoriesServices' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($categories_services)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalafa3b059a847971eaf86fb3f85b67dc6)): ?>
<?php $attributes = $__attributesOriginalafa3b059a847971eaf86fb3f85b67dc6; ?>
<?php unset($__attributesOriginalafa3b059a847971eaf86fb3f85b67dc6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalafa3b059a847971eaf86fb3f85b67dc6)): ?>
<?php $component = $__componentOriginalafa3b059a847971eaf86fb3f85b67dc6; ?>
<?php unset($__componentOriginalafa3b059a847971eaf86fb3f85b67dc6); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.customer-panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programs\OSPanel\domains\mehportal\resources\views/customer/add-order.blade.php ENDPATH**/ ?>