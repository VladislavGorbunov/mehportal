<?php $__env->startSection('title', 'МЕХПОРТАЛ - авторизация администратора'); ?>
<?php $__env->startSection('description', 'Вход в личный кабинет администратора'); ?>

<?php $__env->startSection('content'); ?>

<?php if (isset($component)) { $__componentOriginal475682082900b04cf5c89a36566dfe02 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal475682082900b04cf5c89a36566dfe02 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.login-admin','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.login-admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal475682082900b04cf5c89a36566dfe02)): ?>
<?php $attributes = $__attributesOriginal475682082900b04cf5c89a36566dfe02; ?>
<?php unset($__attributesOriginal475682082900b04cf5c89a36566dfe02); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal475682082900b04cf5c89a36566dfe02)): ?>
<?php $component = $__componentOriginal475682082900b04cf5c89a36566dfe02; ?>
<?php unset($__componentOriginal475682082900b04cf5c89a36566dfe02); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programs\OSPanel\domains\mehportal\resources\views/admin/login-admin.blade.php ENDPATH**/ ?>