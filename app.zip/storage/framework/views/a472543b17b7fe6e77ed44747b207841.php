<div class="d-flex align-items-center " style="height:100vh">
    <div class="col-12 col-md-4 mx-auto login-form-block">
        <form method="post">
            <?php echo csrf_field(); ?>
            <div class="d-flex justify-content-center align-items-center mb-1 flex-column">
                <?php if (isset($component)) { $__componentOriginalef0f557f73dbbb73359670ec0d50c899 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalef0f557f73dbbb73359670ec0d50c899 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.logo','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('site.logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalef0f557f73dbbb73359670ec0d50c899)): ?>
<?php $attributes = $__attributesOriginalef0f557f73dbbb73359670ec0d50c899; ?>
<?php unset($__attributesOriginalef0f557f73dbbb73359670ec0d50c899); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalef0f557f73dbbb73359670ec0d50c899)): ?>
<?php $component = $__componentOriginalef0f557f73dbbb73359670ec0d50c899; ?>
<?php unset($__componentOriginalef0f557f73dbbb73359670ec0d50c899); ?>
<?php endif; ?>
                <p class="m-0 p-0"><small>Вход для администратора</small></p>
            </div>

            <div class="mb-3">
                <label class="form-label">Email:</label>
                <input type="email" class="form-control" placeholder="name@example.ru" name="email" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Пароль:</label>
                <input type="password" class="form-control" placeholder="**********" name="password" required>
            </div>

            <div class="form-check form-switch">
                <input class="form-check-input" type="checkbox" name="remember" role="switch" checked>
                <label class="form-check-label"><small>Запомнить меня на этом компьютере</small></label>
            </div>

            <div class="mt-4 mb-3 text-center ">
                <button type="submit" class="btn btn-login"><i class="bi bi-unlock2"></i> Войти</button>
            </div>
        </form>

        <?php if (isset($component)) { $__componentOriginal4a0e569ed79eb5f00ed3333d1c970f13 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4a0e569ed79eb5f00ed3333d1c970f13 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.errors','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('site.errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4a0e569ed79eb5f00ed3333d1c970f13)): ?>
<?php $attributes = $__attributesOriginal4a0e569ed79eb5f00ed3333d1c970f13; ?>
<?php unset($__attributesOriginal4a0e569ed79eb5f00ed3333d1c970f13); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4a0e569ed79eb5f00ed3333d1c970f13)): ?>
<?php $component = $__componentOriginal4a0e569ed79eb5f00ed3333d1c970f13; ?>
<?php unset($__componentOriginal4a0e569ed79eb5f00ed3333d1c970f13); ?>
<?php endif; ?>

        <div class="square"></div>
        <div class="square-2"></div>
    </div>
</div>
<?php /**PATH D:\Programs\OSPanel\domains\mehportal\resources\views/components/admin/login-admin.blade.php ENDPATH**/ ?>