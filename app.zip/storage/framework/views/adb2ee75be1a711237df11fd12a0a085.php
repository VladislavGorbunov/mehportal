<?php $__env->startSection('title', 'Панель заказчика - МЕХПОРТАЛ'); ?>
<?php $__env->startSection('description', 'Панель заказчика - МЕХПОРТАЛ'); ?>

<?php $__env->startSection('content'); ?>
    <h2 class="fs-4">Личный кабинет заказчика</h2>
        <?php if (isset($component)) { $__componentOriginal5d116857ec1345ea71941ee2547e932b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5d116857ec1345ea71941ee2547e932b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.message','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('site.message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5d116857ec1345ea71941ee2547e932b)): ?>
<?php $attributes = $__attributesOriginal5d116857ec1345ea71941ee2547e932b; ?>
<?php unset($__attributesOriginal5d116857ec1345ea71941ee2547e932b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5d116857ec1345ea71941ee2547e932b)): ?>
<?php $component = $__componentOriginal5d116857ec1345ea71941ee2547e932b; ?>
<?php unset($__componentOriginal5d116857ec1345ea71941ee2547e932b); ?>
<?php endif; ?>
        <?php if(empty($company)): ?> 
            <div class="alert alert-primary text-center mt-3">Добавьте информацию о вашей компании, чтобы получить доступ к размещению заказов.
                    <a href="<?php echo e(Route('customer-add-company')); ?>" class="btn btn-blue mx-2">Добавить компанию</a>
            </div>
        <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.customer-panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programs\OSPanel\domains\mehportal\resources\views/customer/index.blade.php ENDPATH**/ ?>