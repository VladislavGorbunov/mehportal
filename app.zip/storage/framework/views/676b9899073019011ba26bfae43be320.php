<div class="mt-4">
<div class="row">
    <div class="col-12 col-md-4">
        <div class="sticky">
        <img src="<?php echo e(Storage::disk('orders_images')->url($order['order_image'])); ?>" class="img-fluid order-image d-block mx-auto">
        <div class="mt-3 mb-3">
            <div>
                <?php if($order['order_image'] != 'no-image.jpg'): ?>
                    <a href="<?php echo e(Storage::disk('orders_images')->url($order['order_image'])); ?>" target="_blank" class="zoom-link d-flex justify-content-center align-items-center mb-3"><i class="bi bi-zoom-in mx-2"></i> Увеличить чертёж</a>
                <?php endif; ?>
            </div>

            <div>
                <?php if(!empty($order['order_archive'])): ?>
                    <a href="<?php echo e(Storage::disk('orders_files')->url($order['order_archive'])); ?>" class="btn btn-file-download mb-2 d-flex justify-content-center align-items-center"><i class="bi bi-cloud-arrow-down mx-2"></i> Скачать файлы к заказу</a>
                <?php else: ?>
                    <a class="btn btn-file-download-noactive mb-2 d-flex justify-content-center align-items-center"><i class="bi bi-cloud-arrow-down mx-2"></i> Файлы отсутствуют</a>
                <?php endif; ?>
            </div>
        </div>   </div>   
    </div>

    <style>
        .sticky {
            position: sticky;
            top: 20px;
        }
    </style>

    <div class="col-12 col-md-8">
        <div class="row">
            <div class="d-flex flex-column flex-md-row">
                    <p class="mb-3 me-2">Название заказа: <b><?php echo e($order['title']); ?></b></p>
                    <?php if($order['active'] == true): ?>
                        <div class="active-order-badge text-center me-2">Заказ открыт</div>
                    <?php endif; ?>

                    <?php if($order['archive'] == true): ?>
                        <div class="archive-order-badge text-center me-2">Заказ закрыт</div>
                    <?php endif; ?>
                </div>
            <div class="col-12 col-md-6">
                <p class="mb-2">Номер заказа: <b>№<?php echo e($order['id']); ?></b></p>
                <p class="mb-2">Дата размещения: <b><?php echo e($order['date']); ?></b></p>
                <p class="mb-2">Дата сборка КП: <b>до <?php echo e($order['closing_date']); ?></b> - <small>включительно</small></p>
            </div>

            <div class="col-12 col-md-6">
                <p class="mb-2">Необходимое количество: <b><?php echo e($order['quantity']); ?> шт.</b></p>
                <?php if($order['price'] > 0): ?>
                    <p class="mb-2">Проходная цена: <b><?php echo e($order['price']); ?> руб.</b></p>
                <?php else: ?>
                    <p class="mb-2">Проходная цена: <b>Договорная</b></p>
                <?php endif; ?>
            </div>
        </div>

        <p class="mt-3 mb-0"><b>Категории:</b></p>
            <div class="mb-3 mt-2 d-flex flex-wrap">
                <?php $__currentLoopData = $order['services']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($regionSlug !== ''): ?>
                        <div class="services-list me-2 mb-2 d-flex align-items-center"><i class="bi bi-folder-check"></i> <a href="/<?php echo e($regionSlug); ?>/orders/service/<?php echo e($service->slug); ?>"><?php echo e($service->title); ?></a></div>
                    <?php else: ?>
                        <div class="services-list me-2 mb-2 d-flex align-items-center"><i class="bi bi-folder-check"></i> <a href="<?php echo e($regionSlug); ?>/orders/service/<?php echo e($service->slug); ?>"><?php echo e($service->title); ?></a></div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <hr>
        <p class="mb-2"><b>Описание заказа:</b></p>
        <p><?php echo e($order['description']); ?></p>
        <hr>
        <div class="row">
            <p class="mt-3 mb-2"><b>Контакты заказчика:</b></p>
            <?php if(Auth::guard('executor')->user()): ?>
                <?php if(Auth::guard('executor')->user()->premium): ?>
                <div class="col-12 col-md-6">
                    <p class="mb-2">Заказчик: <b><?php echo e($order['company_legal_form']); ?> <?php echo e($order['company_title']); ?></b></p>
                    <p class="mb-2">ИНН заказчика: <b><?php echo e($order['company_inn']); ?></b></p>
                    <p class="mb-2">Регион заказчика: <b><?php echo e($order['region_name']); ?></b></p>
                    <p class="mb-2">Адрес заказчика: <b><?php echo e($order['company_address']); ?></b></p>
                </div>

                <div class="col-12 col-md-6">
                    <p class="mb-2">Контактное лицо: <b><?php echo e($order['person']); ?></b></p>
                    <p class="mb-2">Телефон заказчика: <b><?php echo e($order['company_phone']); ?></b></p>
                    <p class="mb-2">Добавочный: <b><?php echo e($order['extension_number']); ?></b></p>
                    <p class="mb-2">Email заказчика: <b><?php echo e($order['company_email']); ?></b></p>
                </div>
                <?php else: ?>
                <?php if (isset($component)) { $__componentOriginalfa10f4b06dd5a382975b9f4d413b85f8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfa10f4b06dd5a382975b9f4d413b85f8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.hidden-customer-contacts','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('site.hidden-customer-contacts'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfa10f4b06dd5a382975b9f4d413b85f8)): ?>
<?php $attributes = $__attributesOriginalfa10f4b06dd5a382975b9f4d413b85f8; ?>
<?php unset($__attributesOriginalfa10f4b06dd5a382975b9f4d413b85f8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfa10f4b06dd5a382975b9f4d413b85f8)): ?>
<?php $component = $__componentOriginalfa10f4b06dd5a382975b9f4d413b85f8; ?>
<?php unset($__componentOriginalfa10f4b06dd5a382975b9f4d413b85f8); ?>
<?php endif; ?>
                <?php endif; ?>
            <?php endif; ?>
        </div>

        <?php if(Auth::guard('executor')->user()): ?>
            <?php if(!Auth::guard('executor')->user()->premium): ?>
                <div class="alert alert-primary mt-4 text-center">
                    <small>Контакты заказчика доступны зарегистрированным исполнителям с профессиональным тарифом.</small><br>
                    <p class="mt-3 mb-1">Тариф <b>«Профессионал»</b> - от 3990 руб/месяц <a href="" class="buy-tarif ms-2">Подключить</a></p>
                </div>
            <?php endif; ?>
        <?php else: ?>
        <div class="row">
            <?php if (isset($component)) { $__componentOriginalfa10f4b06dd5a382975b9f4d413b85f8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfa10f4b06dd5a382975b9f4d413b85f8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.hidden-customer-contacts','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('site.hidden-customer-contacts'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfa10f4b06dd5a382975b9f4d413b85f8)): ?>
<?php $attributes = $__attributesOriginalfa10f4b06dd5a382975b9f4d413b85f8; ?>
<?php unset($__attributesOriginalfa10f4b06dd5a382975b9f4d413b85f8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfa10f4b06dd5a382975b9f4d413b85f8)): ?>
<?php $component = $__componentOriginalfa10f4b06dd5a382975b9f4d413b85f8; ?>
<?php unset($__componentOriginalfa10f4b06dd5a382975b9f4d413b85f8); ?>
<?php endif; ?>
        </div>
            <div class="alert alert-primary mt-4 text-center">
                <small>Контакты заказчика доступны зарегистрированным исполнителям с профессиональным тарифом.</small><br>
                <p class="mt-3 mb-1">Тариф <b>«Профессионал»</b> - от 3500 руб/месяц <a href="<?php echo e(Route('login-executor')); ?>" class="buy-tarif ms-2" target="_blank">Подключиться</a></p>
            </div>
        <?php endif; ?>

    </div>
</div>
</div><?php /**PATH D:\Programs\OSPanel\domains\mehportal\resources\views/components/site/order.blade.php ENDPATH**/ ?>