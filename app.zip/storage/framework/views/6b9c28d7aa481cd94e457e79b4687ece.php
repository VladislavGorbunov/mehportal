<div class="col-12 col-md-4">
    <div class="sticky">
        <img src="<?php echo e(Storage::disk('orders_images')->url($order['order_image'])); ?>" class="img-fluid order-image d-block mx-auto" alt="Чертёж к заказу - <?php echo e($order['title']); ?>">
            <div class="mt-3 mb-3">
                <div>
                    <?php if($order['order_image'] != 'no-image.jpg'): ?>
                        <a href="<?php echo e(Storage::disk('orders_images')->url($order['order_image'])); ?>" target="_blank" class="zoom-link d-flex justify-content-center align-items-center mb-3"><i class="bi bi-zoom-in mx-2"></i> Увеличить чертёж</a>
                    <?php endif; ?>
                </div>

                <div>
                    <?php if(!empty($order['order_archive'])): ?>
                        <a href="<?php echo e(Storage::disk('orders_files')->url($order['order_archive'])); ?>" class="btn btn-file-download mb-2 d-flex justify-content-center align-items-center"><i class="bi bi-cloud-arrow-down mx-2"></i> Скачать файлы</a>
                    <?php else: ?>
                        <a class="btn btn-file-download-noactive mb-2 d-flex justify-content-center align-items-center"><i class="bi bi-cloud-arrow-down mx-2"></i> Файлы отсутствуют</a>
                    <?php endif; ?>
                </div>
            </div>
    </div>
</div>
<?php /**PATH D:\Programs\OSPanel\domains\mehportal\resources\views/components/site/order/left-order-block.blade.php ENDPATH**/ ?>