<hr>
<p class="mt-2 mb-0 fs-5"><b>Категории:</b></p>
    <div class="mb-3 mt-2 d-flex flex-wrap">
        <?php $__currentLoopData = $order['services']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($regionSlug !== ''): ?>
                <div class="services-list me-2 mb-2 d-flex align-items-center"><i class="bi bi-folder-check"></i> <a href="/<?php echo e($regionSlug); ?>/orders/service/<?php echo e($service->slug); ?>"><?php echo e($service->title); ?></a></div>
            <?php else: ?>
                <div class="services-list me-2 mb-2 d-flex align-items-center"><i class="bi bi-folder-check"></i> <a href="<?php echo e($regionSlug); ?>/orders/service/<?php echo e($service->slug); ?>"><?php echo e($service->title); ?></a></div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<hr><?php /**PATH D:\Programs\OSPanel\domains\mehportal\resources\views/components/site/order/order-categories.blade.php ENDPATH**/ ?>