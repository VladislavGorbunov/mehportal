<?php if (isset($component)) { $__componentOriginal4a0e569ed79eb5f00ed3333d1c970f13 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4a0e569ed79eb5f00ed3333d1c970f13 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.errors','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('site.errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4a0e569ed79eb5f00ed3333d1c970f13)): ?>
<?php $attributes = $__attributesOriginal4a0e569ed79eb5f00ed3333d1c970f13; ?>
<?php unset($__attributesOriginal4a0e569ed79eb5f00ed3333d1c970f13); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4a0e569ed79eb5f00ed3333d1c970f13)): ?>
<?php $component = $__componentOriginal4a0e569ed79eb5f00ed3333d1c970f13; ?>
<?php unset($__componentOriginal4a0e569ed79eb5f00ed3333d1c970f13); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginal5d116857ec1345ea71941ee2547e932b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5d116857ec1345ea71941ee2547e932b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.message','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('site.message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5d116857ec1345ea71941ee2547e932b)): ?>
<?php $attributes = $__attributesOriginal5d116857ec1345ea71941ee2547e932b; ?>
<?php unset($__attributesOriginal5d116857ec1345ea71941ee2547e932b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5d116857ec1345ea71941ee2547e932b)): ?>
<?php $component = $__componentOriginal5d116857ec1345ea71941ee2547e932b; ?>
<?php unset($__componentOriginal5d116857ec1345ea71941ee2547e932b); ?>
<?php endif; ?>
<div class="alert alert-warning text-center mt-3">Все поля обязательны для заполнения.</div>
    <form method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
        <div class="row mt-3">
            <div class="col-12 col-md-6">
                <div class="mb-3">
                    <label class="form-label">Организационно-правовая форма:</label>
                        <select class="form-select" name="legal_form">
                            <?php $__currentLoopData = $legalForms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $legal_form): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(old('legal_form') == $legal_form->name): ?>
                                    <option value="<?php echo e($legal_form->name); ?>" selected><?php echo e($legal_form->name); ?> - <?php echo e($legal_form->full_name); ?></option>
                                <?php else: ?>
                                    <option value="<?php echo e($legal_form->name); ?>"><?php echo e($legal_form->name); ?> - <?php echo e($legal_form->full_name); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                </div>

				<div class="mb-3">
  					<label class="form-label">Название организации:</label>
  					<input type="text" class="form-control" name="title" value="<?php echo e(old('title')); ?>" placeholder="Например: «ТехноСистемы»">
				</div>

				<div class="mb-3">
  					<label class="form-label">ИНН организации:</label>
  					<input type="text" class="form-control" name="inn" value="<?php echo e(old('inn')); ?>" placeholder="Например: 178081376893">
				</div>

				<div class="mb-3">
                    <label class="form-label">Регион:</label>
                        <select class="form-select" name="region_id">
                            <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(old('region') == $region->id): ?>
                                    <option value="<?php echo e($region->id); ?>" selected><?php echo e($region->name); ?></option>
                                <?php else: ?>
                                    <option value="<?php echo e($region->id); ?>"><?php echo e($region->name); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                </div>

				<div class="mb-3">
  					<label class="form-label">Адрес производства:</label>
  					<input type="text" class="form-control" name="address" value="<?php echo e(old('address')); ?>" placeholder="Например: Санкт-Петербург, Боровая улица, д. 51 ">
				</div>
            </div>

            <div class="col-12 col-md-6">
				<div class="mb-3">
  					<label class="form-label">Контактное лицо (Ф.И.О):</label>
  					<input type="text" class="form-control" name="contact_person" value="<?php echo e(old('contact_person')); ?>" placeholder="Например: Иванов Евгений Владимирович">
				</div>

				<div class="mb-3">
  					<label class="form-label">Телефон контактного лица:</label>
  					<input type="tel" class="form-control" name="phone" value="<?php echo e(old('phone')); ?>" placeholder="Например: +7 (123) 456-78-90">
				</div>

				<div class="mb-3">
  					<label class="form-label">Добавочный номер при наличии:</label>
  					<input type="number" class="form-control" name="extension_number" value="<?php echo e(old('extension_number')); ?>" placeholder="Например: 363">
				</div>

				<div class="mb-3">
  					<label class="form-label">Email контактного лица:</label>
  					<input type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" placeholder="Например: petrov-dmk@mail.ru">
				</div>
            </div>
        </div>

        <div class="mb-3">
            <label class="form-label">Описание компании:</label>
            <textarea class="form-control" name="description" rows="6"><?php echo e(old('description')); ?></textarea>
        </div>

        <hr>
        <div class="row mt-4 mb-3">
        <label class="form-label mb-3">В каких категориях вы оказываете услуги:</label>
      
        <?php $__currentLoopData = $categoriesServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            <div class="col-12 col-md-4 mb-4">
                    <label class="form-check-label mt-2">
                           <b><?php echo e($category->title); ?></b>
                    </label>
                    <div class="form-check">
                    <?php $__currentLoopData = $category->servicesAll; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                        <label class="form-check-label mt-2">
                            <input class="form-check-input" type="checkbox" id="services_checkbox" data-parent-id="<?php echo e($category->id); ?>" value="<?php echo e($service->id); ?>" name="categories[]">
                                <?php echo e($service->title); ?>

                        </label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <hr>
        <label class="form-label">Логотип компании: (не обязательно)</label>
            <div class="col-12 col-md-12 mt-2">
                <input type="file" class="logo-executor-company" name="logo" accept=".jpg,.png" hidden>
                <div class="file-column d-flex justify-content-center align-items-center flex-column order-image">
                    <i class="bi bi-file-image fs-1"></i>
                    <p class="m-0 mt-2 title">Логотип компании</p>
                    <span class="m-0"><small>Файл в формате: JPG или PNG</small></span>
                
                </div>
            </div>

		<button type="submit" class="btn btn-blue mt-3 mb-3">Добавить организацию</button>
    </form>


    <script>

    const order_image = document.querySelector('.order-image')
    const order_image_input = document.querySelector('.logo-executor-company')

    order_image.addEventListener('click', () => {
        order_image_input.click()
    })

</script><?php /**PATH D:\Programs\OSPanel\domains\mehportal\resources\views/components/executor/company-data-form.blade.php ENDPATH**/ ?>