<?php $__env->startSection('title', 'МЕХПОРТАЛ - регистрация исполнителя'); ?>
<?php $__env->startSection('description', 'Регистрация исполнителя на портале - МЕХПОРТАЛ'); ?>

<?php $__env->startSection('content'); ?>

<?php if (isset($component)) { $__componentOriginal8b10504f02f05432a816a85bf0ff064e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8b10504f02f05432a816a85bf0ff064e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.executor.registration-executor','data' => ['regions' => $regions]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('executor.registration-executor'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['regions' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($regions)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8b10504f02f05432a816a85bf0ff064e)): ?>
<?php $attributes = $__attributesOriginal8b10504f02f05432a816a85bf0ff064e; ?>
<?php unset($__attributesOriginal8b10504f02f05432a816a85bf0ff064e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b10504f02f05432a816a85bf0ff064e)): ?>
<?php $component = $__componentOriginal8b10504f02f05432a816a85bf0ff064e; ?>
<?php unset($__componentOriginal8b10504f02f05432a816a85bf0ff064e); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.registration', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programs\OSPanel\domains\mehportal\resources\views/executor/registration-executor.blade.php ENDPATH**/ ?>