<div class="col-12 col-md-6 mt-2">
    <?php if($order['customer_premium']): ?> 
        <p class="mb-3">Статус заказчика: <span class="mb-1 premium-customer2"><i class="bi bi-fire"></i> Premium</span></p>
    <?php endif; ?>
    <p class="mb-3">Номер заказа в системе: <b>#<?php echo e($order['id']); ?></b></p>
    <p class="mb-3">Город заказчика:<strong> <?php echo e($order['region_name']); ?></strong></p>
    <p class="mb-3">Дата размещения: <b><?php echo e($order['date']); ?></b></p>
    
</div>

<div class="col-12 col-md-6 mt-2">
    <p class="mb-3">Дата сборка КП: <b>до <?php echo e($order['closing_date']); ?></b> - <small>включительно</small></p>
    <p class="mb-3">Необходимое количество: <b><?php echo e($order['quantity']); ?> шт.</b></p>
        <?php if($order['price'] > 0): ?>
            <p class="mb-3">Проходная цена: <b><?php echo e($order['price']); ?> руб.</b></p>
        <?php else: ?>
            <p class="mb-3">Проходная цена: <b>Договорная</b></p>
        <?php endif; ?>
</div><?php /**PATH D:\Programs\OSPanel\domains\mehportal\resources\views/components/site/order/order-info.blade.php ENDPATH**/ ?>