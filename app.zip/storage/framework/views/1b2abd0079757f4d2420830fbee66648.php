<div class="d-flex align-items-center" style="height: 100vh">
    <div class="col-12 col-md-8 mx-auto registration-form-block">
        <form method="post">
            <?php echo csrf_field(); ?>
            <div class="d-flex justify-content-center align-items-center mb-1 flex-column">
                <?php if (isset($component)) { $__componentOriginalef0f557f73dbbb73359670ec0d50c899 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalef0f557f73dbbb73359670ec0d50c899 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.logo','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('site.logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalef0f557f73dbbb73359670ec0d50c899)): ?>
<?php $attributes = $__attributesOriginalef0f557f73dbbb73359670ec0d50c899; ?>
<?php unset($__attributesOriginalef0f557f73dbbb73359670ec0d50c899); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalef0f557f73dbbb73359670ec0d50c899)): ?>
<?php $component = $__componentOriginalef0f557f73dbbb73359670ec0d50c899; ?>
<?php unset($__componentOriginalef0f557f73dbbb73359670ec0d50c899); ?>
<?php endif; ?>
                <p class="m-0 p-0"><small>Регистрация в роли исполнителя</small></p>
            </div>

            <?php if (isset($component)) { $__componentOriginal4a0e569ed79eb5f00ed3333d1c970f13 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4a0e569ed79eb5f00ed3333d1c970f13 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site.errors','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('site.errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4a0e569ed79eb5f00ed3333d1c970f13)): ?>
<?php $attributes = $__attributesOriginal4a0e569ed79eb5f00ed3333d1c970f13; ?>
<?php unset($__attributesOriginal4a0e569ed79eb5f00ed3333d1c970f13); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4a0e569ed79eb5f00ed3333d1c970f13)): ?>
<?php $component = $__componentOriginal4a0e569ed79eb5f00ed3333d1c970f13; ?>
<?php unset($__componentOriginal4a0e569ed79eb5f00ed3333d1c970f13); ?>
<?php endif; ?>

            <div class="row mt-3">
                <div class="col-12 col-md-6">
                    <div class="mb-3">
                        <label class="form-label">Ваше имя:</label>
                        <input type="text" class="form-control" value="<?php echo e(old('name')); ?>" placeholder="Например: Владимир" name="name" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Фамилия:</label>
                        <input type="text" class="form-control" value="<?php echo e(old('lastname')); ?>" placeholder="Например: Иванов" name="lastname" required>
                    </div>
                   
                    <div class="mb-3">
                        <label class="form-label">Телефон:</label>
                        <input type="tel" autocomplete="tel" type="text" class="form-control" value="<?php echo e(old('phone')); ?>" placeholder="+7 (123) 456-78-90" name="phone" required>
                    </div>

                </div>

                <div class="col-12 col-md-6">
                
                    <div class="mb-3">
                        <label class="form-label">Email:</label>
                        <input type="email" class="form-control" value="<?php echo e(old('email')); ?>" placeholder="Например: evgeni-tsk@mail.ru" name="email" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Пароль для входа: <small>(не менее 8 символов)</small></label>
                        <input type="password" class="form-control" placeholder="" name="password" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Повторите пароль:</label>
                        <input type="password" class="form-control" placeholder="" name="password" required>
                    </div>

                </div>
                <div class="col-12 mt-3">
                    <div class="form-check d-block">
                    <input class="form-check-input" type="checkbox" id="flexCheckChecked" name="checked" checked>
                        <label class="form-check-label" for="flexCheckChecked">
                            <small>Нажимая кнопку «Стать исполнителем», вы подтверждаете согласие с условиями <a href="">Договора-оферты</a> и <a href="">Политикой обработки персональных данных</a>.</small>
                        </label>
                    </div>
                </div>
                <div class="mt-4 text-center ">
                    <button type="submit" class="btn btn-registration">Стать исполнителем</button>
                </div>
            </div>
        </form>

        <div class="square"></div>
        <div class="square-2"></div>
    </div>
</div>


<script>
    const checkbox = document.querySelector('#flexCheckChecked')
    const button = document.querySelector('.btn-registration')
    buttonSwitch()
    
    function buttonSwitch() {
        if (checkbox.checked) {
            console.log('true')
            button.disabled = false
        } else {
            console.log('false')
            button.disabled = true
        }
    }

    checkbox.addEventListener('click', buttonSwitch)
    
</script><?php /**PATH D:\Programs\OSPanel\domains\mehportal\resources\views/components/executor/registration-executor.blade.php ENDPATH**/ ?>