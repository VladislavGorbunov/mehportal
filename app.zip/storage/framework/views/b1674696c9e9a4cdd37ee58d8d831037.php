<?php $__env->startSection('title', 'Панель заказчика - моя компания'); ?>
<?php $__env->startSection('description', 'Панель заказчика - моя компания'); ?>

<?php $__env->startSection('content'); ?>

    <h2 class="fs-4">Моя компания</h2>
        <?php if(empty($company)): ?> 
            <div class="alert alert-primary text-center mt-3">Добавьте информацию о вашей компании, чтобы получить доступ к размещению заказов.
                    <a href="<?php echo e(Route('customer-add-company')); ?>" class="btn btn-blue mx-2">Добавить компанию</a>
            </div>
        <?php else: ?>
            <?php if (isset($component)) { $__componentOriginal423d83d6c0f49a542cd8bc1a63699705 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal423d83d6c0f49a542cd8bc1a63699705 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.customer.company-data-edit','data' => ['company' => $company,'legalForms' => $legal_forms,'regions' => $regions]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('customer.company-data-edit'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['company' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($company),'legalForms' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($legal_forms),'regions' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($regions)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal423d83d6c0f49a542cd8bc1a63699705)): ?>
<?php $attributes = $__attributesOriginal423d83d6c0f49a542cd8bc1a63699705; ?>
<?php unset($__attributesOriginal423d83d6c0f49a542cd8bc1a63699705); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal423d83d6c0f49a542cd8bc1a63699705)): ?>
<?php $component = $__componentOriginal423d83d6c0f49a542cd8bc1a63699705; ?>
<?php unset($__componentOriginal423d83d6c0f49a542cd8bc1a63699705); ?>
<?php endif; ?>
        <?php endif; ?>

        
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.customer-panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programs\OSPanel\domains\mehportal\resources\views/customer/my-company.blade.php ENDPATH**/ ?>